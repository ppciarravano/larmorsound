LarmorSound v.1.0 Beta extension for FabricEngine

Sound spectrum, samples and playback extension for Fabric Engine
Author: Pier Paolo Ciarravano [http://www.larmor.com](http://www.larmor.com)


### Features:

* Extracts audio from all media file types: wav, mp3, mp4, mkv, mts, etc.
* Extracts all audio channels: mono, stereo, 5.1, etc.
* Spectrum output in time per each channel
* Audio energy in time per each channel
* Numeric samples output per channel
* Audio playback reproduction: Fabric Canvas play and stop buttons integrated using internal frame “heartbeat” sync
* Fabric Canvas, Maya and KL demo samples provided
* Windows and Linux versions (Mac OS X version available on January 2017)


### Installation for Fabric Engine 2.3.1 on Windows x86_64:

Extract the zip file in the directory specified by SET FABRIC_EXTS_PATH in your environment.bat e.g.:

C:\FabricEngine-2.3.1-Windows-x86_64\Exts\LarmorSound


### Run Samples:

Examples are at https://github.com/ppciarravano/larmorsound/tree/master/samples

LarmorSound_DEMO_SpectrumViewer.canvas : example for Fabric Canvas.
LarmorSound_DEMO_plate_Canvas.canvas : example for Fabric Canvas.
LarmorSound_DEMO_plate_Maya_2017.mb : example for Autodesk Maya 2017.

For KL demo: edit the file LarmorSound_DEMO_stndln.kl replacing the media filename and execute:

kl LarmorSound_DEMO_stndln.kl


### License:

LarmorSound 1.0 Beta 2016: Extension for Fabric Engine
Copyright (c) 2016 Pier Paolo Ciarravano
http://www.larmor.com
All rights reserved.

LarmorSound is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

LarmorSound is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with LarmorSound. If not, see <http://www.gnu.org/licenses/>.

Licensees holding a valid commercial license may use this file in
accordance with the commercial license agreement provided with the
software.

---
